import Zero
import Events
import Property
import VectorMath
import Keys
import Action
import math
Vec2 = VectorMath.Vec2
Vec3 = VectorMath.Vec3
Vec4 = VectorMath.Vec4
Quat = VectorMath.Quat

class CharacterInput():
    InputType = Property.Bool(default = True)
    GamepadIndex = Property.Int(default = 0)
    
    def Initialize(self, init):
        #Attempt to get the gamepad at the given index
        self.Gamepad = Zero.Gamepads.GetGamePad(self.GamepadIndex)
        
        #Listen for when the character wants input to be updated (to reduce lag)
        Zero.Connect(self.Owner, "UpdateCharacterInput", self.OnUpdateCharacterInput)
        
        #Listen for jumping on up/down events
        if(self.InputType == True):
            Zero.Connect(Zero.Keyboard, Events.KeyDown, self.OnKeyDown)
            Zero.Connect(Zero.Keyboard, Events.KeyUp, self.OnKeyUp)
        elif(self.InputType == False and self.Gamepad):
            Zero.Connect(self.Gamepad, Events.ButtonDown, self.OnButtonDown)
            Zero.Connect(self.Gamepad, Events.ButtonUp, self.OnButtonUp)
    
    def OnUpdateCharacterInput(self, e):
        #Get our movement direction (zero out the y axis so we can't fly)
        movement = self.GetMovementDirection()
        movement.y = 0.0
        
        #set the movement direction on the player
        self.Owner.PlatformerCharacterController.MoveDirection = movement
    
    def GetMovementDirection(self):
        #get our movement direction depending on whether
        #we use keyboard or gamepad input
        if(self.InputType):
            return self.GetKeyboardMovement()
        elif(self.Gamepad):
            return self.GetGamepadMovement()
        
        return Vec3(0.0, 0.0, 0.0)
    
    def OnKeyDown(self, keyboardEvent):
        if(keyboardEvent.Key == Keys.W):
            self.Owner.PlatformerCharacterController.BeginJump()
    
    def OnKeyUp(self, keyboardEvent):
        if(keyboardEvent.Key == Keys.W):
            self.Owner.PlatformerCharacterController.EndJump()
    
    def OnButtonDown(self, gamepadEvent):
        if(gamepadEvent.Button == Buttons.A):
            self.Owner.PlatformerCharacterController.BeginJump()
    
    def OnButtonUp(self, gamepadEvent):
        if(gamepadEvent.Button == Buttons.A):
            self.Owner.PlatformerCharacterController.EndJump()
    
    def GetKeyboardMovement(self):
        dir = Vec3(0.0, 0.0, 0.0)
        
        if(Zero.Keyboard.KeyIsDown(Keys.A)):
            dir += Vec3(-1.0, 0.0, 0.0)
        if(Zero.Keyboard.KeyIsDown(Keys.D)):
            dir += Vec3(1.0, 0.0, 0.0)
        if(Zero.Keyboard.KeyIsDown(Keys.W)):
            dir += Vec3(0.0, 1.0, 0.0)
        if(Zero.Keyboard.KeyIsDown(Keys.D)):
            dir += Vec3(0.0, -1.0, 0.0)
        return dir
    
    def GetGamepadMovement(self):
        return Vec3(self.Gamepad.LeftStick, 0.0)
    
Zero.RegisterComponent("CharacterInput", CharacterInput)