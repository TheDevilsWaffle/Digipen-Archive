import Zero
import Events
import Property
import VectorMath

class CollisionLogic:
    def Initialize(self, initializer):
        #connect to the collision started event 
        Zero.Connect(self.Owner, Events.CollisionStarted, self.OnCollisionStarted)
        pass
        
    def OnCollisionStarted(self, CollisionEvent):
        #destroy the player and game over
        self.Owner.Destroy()

Zero.RegisterComponent("CollisionLogic", CollisionLogic)