import Zero
import Events
import Property
import VectorMath
import Color

Vec3 = VectorMath.Vec3

class EnemyController:
    #pacing properties 
    PaceSpeed = Property.Float(5.0)
    MaxMoveDistance = Property.Float(10.0)
    #chasing properties 
    targetObject = Property.Cog()
    ChaseTriggerDistance = Property.Float(3.0)
    ChaseSpeed = Property.Float(1.0)
    #shooting properties 
    ShootDelay = Property.Float(1.0)
    
    def Initialize(self, initializer):
        #connecting to update the enemy behavior every logic update 
        Zero.Connect(self.Space, Events.LogicUpdate, self.OnLogicUpdate)
        
        #initialize member variables 
        self.PaceDirection = Vec3(1,0,0)
        self.StartPosition = self.Owner.Transform.Translation
        self.DistanceFromTarget = 0.0
        self.ChaseDirection = Vec3(0,0,0)
        self.OriginalColor = self.Owner.Sprite.Color
        self.ChaseColor = Color.Red
        self.NextShot = 0.0
        pass
        
    def OnLogicUpdate(self, UpdateEvent):
        #evaulate if target is in range every logic update 
        targetInRange = False
        
        #if valid TargetObject 
        if(self.targetObject):
            #logic for updating distance from target and chase direction 
            self.CalculateChaseDirectionAndDistance()
            #dertermine whether or not to chase or pace 
            targetInRange = (self.DistanceFromTarget <= self.ChaseTriggerDistance)
            
            #if valid object and target in range
            if(targetInRange):
                #logic for chasing target
                self.ChaseTarget(UpdateEvent)
                #logic for shooting at target
                self.ShootTarget(UpdateEvent)
                print("chasing target")
            else:
                #logic for pacing back and forth
                self.PaceBackAndForth(UpdateEvent)
        else:
            #no valid target, go back to pacing
            self.PaceBackAndForth(UpdateEvent)
        
    def PaceBackAndForth(self, UpdateEvent):
        displacement = self.Owner.Transform.Translation - self.StartPosition
        
        #apply movement 
        self.Owner.Transform.Translation += self.PaceDirection * UpdateEvent.Dt * self.PaceSpeed

        #how far from start position 
        distanceFromStart = displacement.length()
        
        #change direction after reaching max move distance 
        if(distanceFromStart >= self.MaxMoveDistance):
            self.PaceDirection = -displacement
            
        #only want unit length direction 
        self.PaceDirection.normalize()
        
        #set Pacing Color 
        self.Owner.Sprite.Color = self.OriginalColor
        
    def ChaseTarget(self, UpdateEvent):
        #set chase color 
        print("enemy saucer has a target lock on you!")
        
        #start chasing 
        self.Owner.Transform.Translation += self.ChaseDirection * UpdateEvent.Dt * self.ChaseSpeed
        
    def CalculateChaseDirectionAndDistance(self):
        #get direction towards target 
        self.ChaseDirection = self.targetObject.Transform.Translation - self.Owner.Transform.Translation
        #get distance from target 
        self.DistanceFromTarget = self.ChaseDirection.length()
        #only want unit length directions 
        self.ChaseDirection.normalize()
        
    def ShootTarget(self, UpdateEvent):
        #do not shoot until next shot timer is reached 
        if(UpdateEvent.CurrentTime > self.NextShot):
            #update the NextShot counter 
            self.NextShot = UpdateEvent.CurrentTime + self.ShootDelay
            #create projectile at enemy's current position 
            projectileObject = self.Space.CreateAtPosition("EnemyLazor", self.Owner.Transform.Translation)
            #if lazor is shot 
            if(projectileObject):
                #shoot in direction of target (same as chase direction)
                projectileObject.Projectile.Direction = self.ChaseDirection
                #Move it to above our position
                projectileObject.Transform.Translation = self.Owner.Transform.Translation + Vec3(0.0, -1, 0.0)
                #take the enemy's speed into account with projectile speed 
                projectileObject.Projectile.Speed = 5.0 + self.ChaseSpeed
        
Zero.RegisterComponent("EnemyController", EnemyController)