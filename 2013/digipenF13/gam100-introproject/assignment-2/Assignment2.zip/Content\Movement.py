import Zero
import Events
import Property
import VectorMath

Vec3 = VectorMath.Vec3

class Movement:
    def Initialize(self, initializer):
        Zero.Connect(self.Space, Events.LogicUpdate, self.OnLogicUpdate)
        pass

    def OnLogicUpdate(self, UpdateEvent):
        movement = Vec3(0,0,0)
        
        if(Zero.Keyboard.KeyIsDown(Zero.Keys.Right)):
            movement += Vec3(1,0,0)
        if(Zero.Keyboard.KeyIsDown(Zero.Keys.Left)):
            movement += Vec3(-1,0,0)
            
        self.Owner.Transform.Translation += movement * UpdateEvent.Dt * 10.0
            
Zero.RegisterComponent("Movement", Movement)