import Zero
import Events
import Property
import VectorMath
import random
import Keys
import Action

#naming shortcut
Vec3 = VectorMath.Vec3

class PlayerController:
    #Define a speed property that you can access in zero builder
    Speed = Property.Float(default = 1)
    
    #comments are created using pound key "#"
    def Initialize(self, intializer):
            print("Self: ", self)
            print("Space: ", self.Space)
            print("Owner: ", self.Owner)
            #when space object has a change perform OnLogicUpdate function
            Zero.Connect(self.Space, Events.LogicUpdate, self.OnLogicUpdate)
                        
            #initializing the shooting function
            Zero.Connect(Zero.Keyboard, Events.KeyDown, self.FiringMahLazors)
            pass
            
    #print to console the UpdateEvent Delta Time
    def OnLogicUpdate(self, UpdateEvent):
        #generate random asteroids 
        if(Zero.Keyboard.KeyIsPressed(Zero.Keys.Enter)):
            #generate random number to be used to create asteroids 
            asteroidsInWorld = random.randint(100, 300)
            print("asteroidsInWorld: ", asteroidsInWorld)
            #loop to create all asteroids in world
            for num in range (0, asteroidsInWorld):
                #generate random floats for x and y position of asteroids 
                randomPosX = random.uniform(-40, 40)
                randomPosY = random.uniform(-40, 40)
                randomPosition = Vec3(randomPosX, randomPosY)
                #generate random integer for asteroid type creation 
                randomObjectNumber = random.randint(1, 3)
                #print("randomObjectNumber is ", randomObjectNumber);
                #create a random asteroid type based on a random object number value with a random position
                if(randomObjectNumber == 1):
                    self.Space.CreateAtPosition("BlueBall",randomPosition)
                    #print("making a blue ball")
                elif(randomObjectNumber == 2):
                    self.Space.CreateAtPosition("RedBall",randomPosition)
                    #print("making a red ball")
                elif(randomObjectNumber == 3):
                    self.Space.CreateAtPosition("GreenBall",randomPosition)
                    #print("making a green ball")

            #generate the enemies in the world
            enemiesInWorld = random.randint(5, 10)
            print("enemiesInWorld: ", enemiesInWorld)
            #create variable to keep track of saucers left in world 
            enemiesRemaining = enemiesInWorld
            #start loop 
            for num in range (0, enemiesInWorld):
                #generate random floats for x and y position of enemies 
                randomPosX = random.uniform(-30, 30)
                randomPosY = random.uniform(-30, 30)
                randomPosition = Vec3(randomPosX, randomPosY)
                #create an enemy with a random position
                self.Space.CreateAtPosition("Enemy",randomPosition)
            else:
                print("There are ", enemiesInWorld, "Flying Saucers\nGo get 'em!")
                
            #keep track of saucers and report to player as they are destroyed

        movement = Vec3(0, 0, 0)
        #Movement Upwards
        if(Zero.Keyboard.KeyIsDown(Zero.Keys.W)):
            movement.y = self.Speed
            pass
        #Movement Downwards
        if(Zero.Keyboard.KeyIsDown(Zero.Keys.S)):
            movement.y = -self.Speed
            pass
        #Movement Left    
        if(Zero.Keyboard.KeyIsDown(Zero.Keys.A)):
            movement.x = -self.Speed
            pass
        #Movement Right    
        if(Zero.Keyboard.KeyIsDown(Zero.Keys.D)):
            movement.x = self.Speed
            pass
        #the player can go faster than our target speed if they hold down W and A so normalize the movement vector so that it's unit length
        movement = movement.normalized()
        speed = 5.0
        self.Owner.Transform.Translation += movement * speed * UpdateEvent.Dt
        pass
    
    def FiringMahLazors(self, KeyboardEvent):
        #firing with the space key
        if(KeyboardEvent.Key == Zero.Keys.Space):
            #Create the lazor object
            lazor = self.Space.Create("PlayerLazor")
            #Move it to above our position
            lazor.Transform.Translation = self.Owner.Transform.Translation + Vec3(0.0, 0.95, 0.0)
            #Give the bullet an initial velocity
            lazor.RigidBody.Velocity = Vec3(0.0, 10.0, 0.0)
            print("pew!")
            
Zero.RegisterComponent("PlayerController", PlayerController)