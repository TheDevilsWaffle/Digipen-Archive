import Zero
import Events
import Property
import VectorMath
import Color

class lazorCollision:
    def Initialize(self, initializer):
        #connect to the lazor collision started event 
        Zero.Connect(self.Owner, Events.CollisionStarted, self.OnCollisionStarted)
        pass
        
    def OnCollisionStarted(self, CollisionEvent):
        #destroy the lazor
        self.Owner.Destroy()
        #destroy the object that the lazor hit 
        
        #announce to player that they hit something
        print("Direct Hit!")


Zero.RegisterComponent("lazorCollision", lazorCollision)