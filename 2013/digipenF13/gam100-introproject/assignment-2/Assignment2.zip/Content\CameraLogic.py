import Zero
import Events
import Property
import VectorMath

class CameraLogic:
    #object to follow 
    targetObject = Property.Cog()
    
    def Initialize(self, initializer):
        Zero.Connect(self.Space, Events.LogicUpdate, self.OnLogicUpdate)
        
    def OnLogicUpdate(self, UpdateEvent):
        #get our current translation 
        currentTranslation = self.Owner.Transform.Translation
        if(self.targetObject):
            #get target objects' translation 
            targetTranslation = self.targetObject.Transform.Translation
            #use x y and z position  
            newTranslation = VectorMath.Vec3(targetTranslation.x, targetTranslation.y, currentTranslation.z)
            #update our translation with the new translation 
            self.Owner.Transform.Translation = newTranslation
        else:
            print("game over")

Zero.RegisterComponent("CameraLogic", CameraLogic)