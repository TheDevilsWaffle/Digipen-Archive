import Zero
import Events
import Property
import VectorMath

class ScaleRegionLogic:
    def Initialize(self, initializer):
        #listen for keyboard input
        Zero.Connect(Zero.Keyboard, Events.KeyDown, self.OnKeyDown)
        
    def OnKeyDown(self, KeyboardEvent):
        #check for number 2 key being pressed
        if(KeyboardEvent.Key == Zero.Keys.S):
            #create custom event
            scaleEvent = Zero.ScriptEvent()
            #make uobjects twice as big
            scaleEvent.scaleFactor = .75
            #dispatch event to all objects within this region
            self.Owner.Region.DispatchEvent("ScaleObjectEvent", scaleEvent)

Zero.RegisterComponent("ScaleRegionLogic", ScaleRegionLogic)