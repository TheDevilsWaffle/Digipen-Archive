import Zero
import Events
import Property
import VectorMath

Vec3 = VectorMath.Vec3

class Bullet:
    Speed = Property.Float(1.0)
    Direction = Property.Vector3(Vec3(0,0,0))
    
    def Initialize(self, initializer):
        #connect function to update the projectile's movement every logic update 
        Zero.Connect(self.Space, Events.LogicUpdate, self.OnLogicUpdate)
        Zero.Connect(self.Owner, Events.CollisionStarted, self.OnCollisionStarted)
        
    def OnLogicUpdate(self, UpdateEvent):
        #apply movement to projectile 
        self.Owner.Transform.Translation += self.Direction * UpdateEvent.Dt * self.Speed
        
    def OnCollisionStarted(self, CollisionEvent):
        #destroy the lazor
        self.Owner.Destroy()
        

Zero.RegisterComponent("Bullet", Bullet)