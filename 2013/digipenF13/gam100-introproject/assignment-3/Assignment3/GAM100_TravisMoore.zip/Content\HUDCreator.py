import Zero
import Events
import Property
import VectorMath

class HUDCreator:
    #the level with out HUD objects
    LevelForHUD = Property.Resource("Level")
    
    def Initialize(self, initializer):
        #create the space for the HUD objects
        self.HUDSpace = Zero.Game.CreateNamedSpace("HUDSpace", "Space")
        
        #Load the level without HUD objects into the HUD space
        self.HUDSpace.LoadLevel(self.LevelForHUD)
        
    def Destroyed(self):
        #Destroy the HUD space and all objects inside it
        self.HUDSpace.Destroy()
        
Zero.RegisterComponent("HUDCreator", HUDCreator)