import Zero
import Events
import Property
import VectorMath

class RegionDeath:
    def Initialize(self, initializer):
        #listen for KillPlayer
        Zero.Connect(Zero.Space, Events.LogicUpdate, self.KillPlayer)
        
    def KillPlayer(self, UpdateEvent):
        #get the other object involved in the collision
        playerHit = collisionEvent

Zero.RegisterComponent("RegionDeath", RegionDeath)