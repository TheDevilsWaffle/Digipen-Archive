import Zero
import Events
import Property
import VectorMath

class GameLogic:
    def Initialize(self, initializer):
        #we want to check for input ever logic update
        Zero.Connect(self.Space, Events.LogicUpdate, self.OnLogicUpdate)
        
        #keep track of seconds pased
        self.secondsPassed = 0.0
        
    def OnLogicUpdate(self, UpdateEvent):
        #update seconds passed with delta time
        self.secondsPassed += UpdateEvent.Dt
            
        #get a reference to the HUD Space
        hudSpace = Zero.Game.FindSpaceByName("HUDSpace")
        
        #get a reference to the TextTimePassed
        textTimePassedObject = hudSpace.FindObjectByName("TextTimePassed")
        #update the HUD text object's SpriteText
        textTimePassedObject.SpriteText.Text = "Time: " + str(round(self.secondsPassed, 1)) + " seconds"
        
        #LEVEL LOADING
        
        #reload the level when the enter key is pressed
        if(Zero.Keyboard.KeyIsPressed(Zero.Keys.R)):
            self.Space.ReloadLevel()
        
        #switch the level when the right arrow key is pressed
        if(Zero.Keyboard.KeyIsPressed(Zero.Keys.Down)):
            #get the name of the curretly loaded level
            currentLevelName = self.Space.CurrentLevel.Name
        
        #keep track of player status
        playerStatus = 0
            
        #reload the level when the enter key is pressed
        if(Zero.Keyboard.KeyIsPressed(Zero.Keys.R)):
            self.Space.ReloadLevel()
            playerStatus = 1
        
        #store current level name
        currentLevelName = self.Space.CurrentLevel.Name
        #switch the level when the right arrow key is pressed
        if(Zero.Keyboard.KeyIsPressed(Zero.Keys.Enter)):
            
            #if curently Level_Start, then load Level_1
            if(currentLevelName == "Level_Start"):
                print("Currently on " + currentLevelName + " loading Level_1")
                self.Space.LoadLevel("Level_1")
                playerStatus = 1
                
            #if currently Level_1, then load Level_1 again
            elif(currentLevelName == "Level_1"):
                print("Currently playing " + currentLevelName + " loading Level_1")
                self.Space.LoadLevel("Level_1")
                playerStatus = 1
                
            #if player dies, load Level_Lose
            elif(currentLevelName == "Level_1" and playerStatus == 0):
                print("Currently on " + currentLevelName + " loading Level_1")
                self.Space.LoadLevel("Level1")
                
            #if currently on Level_Lose, load Level_1 so the player can try again
            elif(currentLevelName == "Level_Lose" and playerStatus == 0):
                print("Currently on " + currentLevelName + " loading Level_1")
                self.Space.LoadLevel("Level_1")
                playerStatus = 1
                
            #if currently on Level_Win, load Level_Start
            elif(currentLevelName == "Level_Win"):
                print("Currently on " + currentLevelName + " loading Level_Start")
                self.Space.LoadLevel("Level_Start")
                
        #if currently on Level_1 and player wins, load Level_Win
        if(currentLevelName == "Level_1" and playerStatus == 2):
            print("Currently playing " + currentLevelName + " loading Level_Win")
            self.Space.LoadLevel("Level_Win")
            
        #PLAYER DYING
        #if player 
        
Zero.RegisterComponent("GameLogic", GameLogic)