import Zero
import Events
import Property
import VectorMath

class ScaleLogic:
    def Initialize(self, initializer):
        #listen for the ScaleObject event to be sent on us
        Zero.Connect(self.Owner, "ScaleObjectEvent", self.OnScaleObject)
        
    def OnScaleObject(self, ScaleObjectEvent):
        print("Performing scale");
        #scale this object by the scale factor
        self.Owner.Transform.Scale *= ScaleObjectEvent.scaleFactor
        #always make sure the player isn't crazy with jumpspeed and movement now
        #get a reference to the PlayerMovement speed and jump PyScript
        PlayerSpeed = Zero.Game.FindSpaceByName("moveSpeed")
        print("PlayerSpeed = " + str(PlayerSpeed))
        PlayerJump = Zero.Game.FindSpaceByName("jumpSpeed")
        print("PlayerJump = " + str(PlayerSpeed))


        PlayerSpeed = Property.Float(0.1)
        PlayerJump = Property.Float(1.0)
Zero.RegisterComponent("ScaleLogic", ScaleLogic)