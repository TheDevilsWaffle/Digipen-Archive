import Zero
import Events
import Property
import VectorMath

class PointsRegion:
    def Initialize(self, initializer):
        #we want to check for input ever logic update
        Zero.Connect(self.Space, Events.LogicUpdate, self.OnLogicUpdate)
        
        #keep track of the score
        self.score = 0
        
    def OnLogicUpdate(self, UpdateEvent):
        #check for P key being pressed
        if(Zero.Keyboard.KeyIsPressed(Zero.Keys.P)):
            #increment score when shift is pressed
            self.score += 1
            #get a reference to the HUD Space
            hudSpace = Zero.Game.FindSpaceByName("HUDSpace")
            #get a reference to the TextScore
            textScoreObject = hudSpace.FindObjectByName("TextScore")
            #update the HUD text object's SpriteText
            textScoreObject.SpriteText.Text = "Score: " + str(self.score)

Zero.RegisterComponent("PointsRegion", PointsRegion)