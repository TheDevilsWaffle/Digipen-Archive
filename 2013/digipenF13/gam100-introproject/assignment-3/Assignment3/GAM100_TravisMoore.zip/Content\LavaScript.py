import Zero
import Events
import Property
import VectorMath

class LavaScript:
    def Initialize(self, initializer):
        pass

Zero.RegisterComponent("LavaScript", LavaScript)