import Zero
import Events
import Property
import VectorMath

Vec3 = VectorMath.Vec3

class PlayerMovement:
    moveSpeed = Property.Float(0.5)
    jumpSpeed = Property.Float(30.0)
    
    def Initialize(self, initializer):
        #we want to apply movement every logic update 
        Zero.Connect(self.Space, Zero.Events.LogicUpdate, self.OnLogicUpdate)
        
    def OnLogicUpdate(self, UpdateEvent):
        #get all input from the player here
        self.UpdatePlayerInput()
        #Logic for player movement
        self.ApplyMovement()
        #logic for player jumping
        self.ApplyJumping()
        
    def UpdatePlayerInput(self):
        #the player is attempting to move left or right
        self.moveRight = Zero.Keyboard.KeyIsDown(Zero.Keys.D)
        self.moveLeft = Zero.Keyboard.KeyIsDown(Zero.Keys.A)
        #the player is attemping to jump
        self.moveJump = Zero.Keyboard.KeyIsPressed(Zero.Keys.Space)
        
    def ApplyMovement(self):
        moveDirection = Vec3(0,0,0)
        #apply movement based on player input
        if(self.moveRight):
            moveDirection += Vec3(1,0,0)
        if(self.moveLeft):
            moveDirection += Vec3(-1,0,0)
        
        #Only want unit direction
        moveDirection.normalize()
        
        #applying movement linear velocity
        self.Owner.RigidBody.ApplyLinearVelocity(moveDirection * self.moveSpeed)
        
    def ApplyJumping(self):
        #apply an instant force upward for jumping based on player input
        if(self.moveJump):
            self.Owner.RigidBody.ApplyLinearImpulse(Vec3(0,1,0) * self.jumpSpeed)

Zero.RegisterComponent("PlayerMovement", PlayerMovement)