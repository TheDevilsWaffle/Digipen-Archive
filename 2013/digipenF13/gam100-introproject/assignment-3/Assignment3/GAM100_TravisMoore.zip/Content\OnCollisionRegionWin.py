import Zero
import Events
import Property
import VectorMath

class OnCollisionRegionWin:
    def Initialize(self, initializer):
        #connect to the collision started event 
        Zero.Connect(self.Owner, Events.CollisionStarted, self.OnCollisionStarted_RegionWin)
        pass
        
    def OnCollisionStarted_RegionWin(self, CollisionEvent):
        #get current level name
        currentLevelName = self.Space.CurrentLevel.Name
        #load Level_Lose
        print("Player has won. Loading Level_Win")
        self.Space.LoadLevel("Level_Win")
        
Zero.RegisterComponent("OnCollisionRegionWin", OnCollisionRegionWin)