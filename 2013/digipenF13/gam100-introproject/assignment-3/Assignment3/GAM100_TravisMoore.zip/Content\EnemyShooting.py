import Zero
import Events
import Property
import VectorMath

Vec3 = VectorMath.Vec3

class EnemyShooting:
    Bullet = Property.Archetype()
    ShootDelay = Property.Float(1.0)
    
    def Initialize(self, initializer):
        Zero.Connect(self.Space, Events.LogicUpdate, self.ShootTarget)
        #initialize member variables 
        self.NextShot = 0.0
    
    def ShootTarget(self, UpdateEvent):
        #do not shoot until next shot timer is reached 
        if(UpdateEvent.CurrentTime > self.NextShot):
            #update the NextShot counter 
            self.NextShot = UpdateEvent.CurrentTime + self.ShootDelay
            #create projectile at enemy's current position 
            projectileObject = self.Space.CreateAtPosition("Bullet", self.Owner.Transform.Translation)
            #if lazor is shot 
            if(projectileObject):
                #Create the bullet object
                bullet = self.Space.Create(self.Bullet)
                #Move it to above our position
                bullet.Transform.Translation = self.Owner.Transform.Translation + Vec3(-2, 0, 0.0)
                #Give the bullet an initial velocity
                bullet.RigidBody.Velocity = Vec3(-20.0, 0.0, 0.0)
        
Zero.RegisterComponent("EnemyShooting", EnemyShooting)