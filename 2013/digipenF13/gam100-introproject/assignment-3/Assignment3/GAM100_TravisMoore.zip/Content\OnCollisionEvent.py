import Zero
import Events
import Property
import VectorMath

class OnCollisionEvent:
    def Initialize(self, initializer):
        #connect to the collision started event 
        Zero.Connect(self.Owner, Events.CollisionStarted, self.OnCollisionStarted)
        pass
        
    def OnCollisionStarted(self, CollisionEvent):
        #destroy the player and game over
        self.Owner.Destroy()
        #get current level name
        currentLevelName = self.Space.CurrentLevel.Name
        #load Level_Lose
        print("Player has died. Loading Level_Lose")
        self.Space.LoadLevel("Level_Lose")

Zero.RegisterComponent("OnCollisionEvent", OnCollisionEvent)