PROJECT:  Super Space Race

XBOX GAMEPAD CONTROLS
MENUS:
	CONFIRM  - A Button
	BACK 	 - B Button

IN-GAME:
	SHOOT - Left Trigger
	THROTTLE - Right Trigger
	SPEED BOOST - R3 (Press and hold Right Analog Stick)
	BRAKE/RECHARGE LASERS & SHIELDS	 - Right Bumper
	PITCH/YAW - Left Analog Stick
	ROLL - Right Analog Stick
	PAUSE - Start/Menu Button

DETAILS:
	While the game is not complete, the idea is to make a space flight racing game with limited energy management between your shields, lasers, and throttle. Holding throttle will slowly drain the power from your shields/lasers, while letting go of throttle and breaking will recharge your shields/lasers. Boosting to go faster will dramatically increase the drain rate of your shields/lasers.

That's all for now.