Ian & Michael,
Still working on the 6 mini games, but i'll email them when they are done.

I'm sending you guys these completed wireframes in the meantime to make sure
we're okay with the work I'm doing and to catch anything that I might have
missed.

-Travis